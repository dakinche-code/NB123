NORTH STAR BAKERY — TOUCHSTONE 3

Original bakery media from Bakery_c.zip is now included.
Open index.html in your IDE preview or browser.
Test each page, link, image, audio player, and form at 375px, 768px and 1280px.
Publish this folder to a public GitHub repository and enable GitHub Pages for a public preview.
Insert your actual GitHub repository URL, live preview URL and screenshot into the design explanation document.
The contact form is a classroom demo, not an operational order system.
The original supplied video and alternate audio track were not used because Touchstone 2 used audio only.
